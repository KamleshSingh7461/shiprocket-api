const mongoose = require('mongoose');

const VariantSchema = new mongoose.Schema({
  id: Number,
  title: String,
  price: String,
  sku: String,
  created_at: String,
  updated_at: String,
  taxable: Boolean,
  grams: Number,
  image: {
    src: String
  },
  weight: Number,
  weight_unit: String
});

const ProductSchema = new mongoose.Schema({
  id: Number,
  title: String,
  body_html: String,
  vendor: String,
  product_type: String,
  created_at: String,
  updated_at: String,
  handle: String,
  tags: String,
  status: String,
  collection_id: Number, // ✅ Correctly added here
  variants: [VariantSchema],
  image: {
    src: String
  }
});


module.exports = mongoose.model('Product', ProductSchema);

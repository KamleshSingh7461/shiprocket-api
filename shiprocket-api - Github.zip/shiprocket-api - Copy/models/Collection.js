const mongoose = require('mongoose');

const CollectionSchema = new mongoose.Schema({
  id: Number,
  title: String,
  body_html: String,
  handle: String,
  created_at: String,
  updated_at: String,
  image: {
    src: String
  }
});

module.exports = mongoose.model('Collection', CollectionSchema);

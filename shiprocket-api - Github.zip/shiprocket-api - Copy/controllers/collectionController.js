const Collection = require('../models/Collection');
const Product = require('../models/Product');

// GET /collections-list
const getAllCollections = async (req, res) => {
  const page = parseInt(req.query.page) || 0;
  const limit = parseInt(req.query.limit) || 12;

  try {
    const total = await Collection.countDocuments();
    const collections = await Collection.find()
      .skip(page * limit)
      .limit(limit);

    res.json({
      data: {
        total,
        collections
      }
    });
  } catch (error) {
    console.error('❌ Error fetching collections:', error);
    res.status(500).json({ success: false, message: 'Error fetching collections' });
  }
};

// GET /collection-product-list
const getProductsByCollection = async (req, res) => {
  const {
    collection_id,
    page = 0,
    limit = 10,
    search,
    sort,
    vendor,
    product_type,
    tags,
    min_price,
    max_price
  } = req.query;

  const parsedPage = parseInt(page);
  const parsedLimit = parseInt(limit);
  const skip = parsedPage * parsedLimit;

  const query = {};

  if (collection_id) query.collection_id = parseInt(collection_id);
  if (search) query.title = { $regex: search, $options: 'i' };
  if (vendor) query.vendor = vendor;
  if (product_type) query.product_type = product_type;
  if (tags) query.tags = { $regex: tags, $options: 'i' };

  const priceFilter = {};
  const min = parseFloat(min_price);
  const max = parseFloat(max_price);
  if (!isNaN(min)) priceFilter.$gte = min;
  if (!isNaN(max)) priceFilter.$lte = max;

  try {
    const total = await Product.countDocuments(query);

    const products = await Product.aggregate([
      { $match: query },
      {
        $addFields: {
          firstVariant: { $arrayElemAt: ["$variants", 0] }
        }
      },
      ...(Object.keys(priceFilter).length > 0
        ? [{
            $match: {
              "firstVariant.price": priceFilter
            }
          }]
        : []),
      ...(sort === 'asc' || sort === 'desc'
        ? [{ $sort: { "firstVariant.price": sort === 'asc' ? 1 : -1 } }]
        : []),
      { $skip: skip },
      { $limit: parsedLimit },
      {
        $project: {
          id: 1,
          title: 1,
          body_html: 1,
          vendor: 1,
          product_type: 1,
          created_at: 1,
          updated_at: 1,
          handle: 1,
          tags: 1,
          status: 1,
          collection_id: 1,
          image: 1,
          variants: 1,
          firstVariant: {
            price: "$firstVariant.price",
            compare_at_price: "$firstVariant.compare_at_price",
            available: "$firstVariant.available"
          }
        }
      }
    ]);

    res.json({
      data: {
        total,
        products
      }
    });
  } catch (error) {
    console.error('❌ Error fetching products by collection:', error);
    res.status(500).json({ success: false, message: 'Error fetching products by collection' });
  }
};

module.exports = {
  getAllCollections,
  getProductsByCollection
};

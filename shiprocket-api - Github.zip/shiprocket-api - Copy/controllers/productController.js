const Product = require('../models/Product');

// GET /product-list
const getAllProducts = async (req, res) => {
  const {
    page = 0,
    limit = 12,
    search,
    sort,
    vendor,
    product_type,
    tags,
    min_price,
    max_price
  } = req.query;

  const parsedPage = parseInt(page);
  const parsedLimit = parseInt(limit);
  const skip = parsedPage * parsedLimit;

  const query = {};

  // Filter by title (search)
  if (search) {
    query.title = { $regex: search, $options: 'i' };
  }

  // Filter by vendor
  if (vendor) {
    query.vendor = vendor;
  }

  // Filter by product_type
  if (product_type) {
    query.product_type = product_type;
  }

  // Filter by tags
  if (tags) {
    query.tags = { $regex: tags, $options: 'i' };
  }

  // Price filters (min_price, max_price)
  const priceFilter = {};
  const min = parseFloat(min_price);
  const max = parseFloat(max_price);
  if (!isNaN(min)) priceFilter.$gte = min;
  if (!isNaN(max)) priceFilter.$lte = max;

  // Aggregation pipeline for MongoDB query
  try {
    const total = await Product.countDocuments(query);

    const products = await Product.aggregate([
      { $match: query },
      {
        $addFields: {
          firstVariant: { $arrayElemAt: ["$variants", 0] }
        }
      },
      ...(Object.keys(priceFilter).length > 0
        ? [{
            $match: {
              "firstVariant.price": priceFilter
            }
          }]
        : []),
      ...(sort === 'asc' || sort === 'desc'
        ? [{ $sort: { "firstVariant.price": sort === 'asc' ? 1 : -1 } }]
        : []),
      { $skip: skip },
      { $limit: parsedLimit },
      {
        $project: {
          id: 1,
          title: 1,
          body_html: 1,
          vendor: 1,
          product_type: 1,
          created_at: 1,
          updated_at: 1,
          handle: 1,
          tags: 1,
          status: 1,
          collection_id: 1,
          image: 1,
          variants: 1
        }
      }
    ]);

    // Send response in Shiprocket format
    res.json({
      data: {
        total,
        products
      }
    });
  } catch (error) {
    console.error('❌ Error fetching products:', error);
    res.status(500).json({ success: false, message: 'Error fetching products' });
  }
};

module.exports = {
  getAllProducts
};

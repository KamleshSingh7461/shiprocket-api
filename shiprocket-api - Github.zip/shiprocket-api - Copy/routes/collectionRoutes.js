const express = require("express");
const router = express.Router();
const {
  getAllCollections,
  getProductsByCollection,
} = require("../controllers/collectionController");

const { query, validationResult } = require("express-validator");

// Route: GET /collections-list
router.get("/collections-list", getAllCollections);

// Route: GET /collection-product-list
router.get(
  "/collection-product-list",
  [
    query("collection_id").notEmpty().withMessage("collection_id is required"),
    query("page").optional().isInt({ min: 0 }).withMessage("page must be >= 0"),
    query("limit").optional().isInt({ min: 1 }).withMessage("limit must be >= 1"),
    query("sort").optional().isIn(["asc", "desc"]).withMessage("sort must be 'asc' or 'desc'"),
    query("min_price").optional().isFloat({ min: 0 }),
    query("max_price").optional().isFloat({ min: 0 }),
  ],
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }
    next();
  },
  getProductsByCollection
);

module.exports = router;



// GET /collection-product-list
router.get('/collection-product-list', async (req, res) => {
  const {
    collection_id,
    page = 0,
    limit = 10,
    search,
    sort,
    vendor,
    product_type,
    tags,
    min_price,
    max_price
  } = req.query;

  const query = {};

  // Filter by collection_id
  if (collection_id) {
    query.collection_id = parseInt(collection_id);
  }

  // Search by product title
  if (search) {
    query.title = { $regex: search, $options: 'i' };
  }

  // Filter by vendor
  if (vendor) {
    query.vendor = vendor;
  }

  // Filter by product_type
  if (product_type) {
    query.product_type = product_type;
  }

  // Filter by tags (case-insensitive regex)
  if (tags) {
    query.tags = { $regex: tags, $options: 'i' };
  }

  // Prepare price filter object
  const priceFilter = {};
  const min = parseFloat(min_price);
  const max = parseFloat(max_price);
  if (!isNaN(min)) priceFilter.$gte = min;
  if (!isNaN(max)) priceFilter.$lte = max;

  try {
    const total = await Product.countDocuments(query);

    const products = await Product.aggregate([
      { $match: query },
      {
        $addFields: {
          firstVariant: { $arrayElemAt: ["$variants", 0] }
        }
      },
      ...(Object.keys(priceFilter).length > 0
        ? [{
            $match: {
              "firstVariant.price": priceFilter
            }
          }]
        : []),
      ...(sort === 'asc' || sort === 'desc'
        ? [{ $sort: { "firstVariant.price": sort === 'asc' ? 1 : -1 } }]
        : []),
      { $skip: parseInt(page) * parseInt(limit) },
      { $limit: parseInt(limit) },
      {
        $project: {
          id: 1,
          title: 1,
          body_html: 1,
          vendor: 1,
          product_type: 1,
          created_at: 1,
          updated_at: 1,
          handle: 1,
          tags: 1,
          status: 1,
          collection_id: 1,
          image: 1,
          variants: 1
        }
      }
    ]);

    res.json({
      success: true,
      data: {
        total,
        products
      }
    });
  } catch (error) {
    console.error('❌ Error fetching products by collection:', error);
    res.status(500).json({ success: false, message: 'Error fetching products by collection' });
  }
});

module.exports = router;

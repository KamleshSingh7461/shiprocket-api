const express = require('express');
const router = express.Router();
const Product = require('../models/Product');

// GET /product-list
router.get('/product-list', async (req, res) => {
  const page = parseInt(req.query.page) || 1; // default page = 1
  const limit = parseInt(req.query.limit) || 12; // match Shiprocket docs
  const skip = (page - 1) * limit;

  try {
    const total = await Product.countDocuments();
    const products = await Product.find()
      .skip(skip)
      .limit(limit);

    res.json({
      success: true,
      data: {
        total,
        products
      }
    });
  } catch (error) {
    console.error('❌ Error fetching products:', error);
    res.status(500).json({ success: false, message: 'Error fetching products' });
  }
});


module.exports = router;

const express = require('express');
const router = express.Router();

const { getAllProducts } = require('../controllers/productController');
const { getAllCollections, getProductsByCollection } = require('../controllers/collectionController');

router.get('/product-list', getAllProducts);
router.get('/collections-list', getAllCollections);
router.get('/collection-product-list', getProductsByCollection);

module.exports = router;


// 1. GET /product-list
router.get('/product-list', async (req, res) => {
  try {
    const products = await Product.find();
    res.json({ success: true, products });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error fetching products' });
  }
});

// 2. GET /collections-list
router.get('/collections-list', async (req, res) => {
  try {
    const collections = await Collection.find();
    res.json({ success: true, collections });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error fetching collections' });
  }
});

// 3. GET /collection-product-list/:collectionId
router.get('/collection-product-list/:collectionId', async (req, res) => {
  try {
    const collectionId = req.params.collectionId;
    const products = await Product.find({ collectionId });
    res.json({ success: true, products });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error fetching products by collection' });
  }
});

module.exports = router;

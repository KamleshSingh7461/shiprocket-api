const mongoose = require('mongoose');
require('dotenv').config();
const Product = require('../models/Product');
const Collection = require('../models/Collection');

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(async () => {
  console.log('✅ Connected for seeding');

  await Product.deleteMany();
  await Collection.deleteMany();

  const collections = await Collection.insertMany([
    {
      id: 1001,
      title: "Smart iPods",
      handle: "smart-ipods",
      body_html: "<p>The best selling ipod ever</p>",
      image: {
        src: "https://cdn.shopify.com/s/files/1/0005/4838/0009/collections/ipod_nano_8gb.jpg"
      },
      created_at: new Date(),
      updated_at: new Date()
    },
    {
      id: 1002,
      title: "IPods",
      handle: "ipods",
      body_html: "<p>The best selling ipod ever</p>",
      image: {
        src: "https://cdn.shopify.com/s/files/1/0005/4838/0009/collections/ipod_nano_8gb.jpg"
      },
      created_at: new Date(),
      updated_at: new Date()
    }
  ]);

  await Product.insertMany([
    {
      id: 632910392,
      title: "IPod Nano - 8GB",
      body_html: "<p>Small iPod. Big idea: Video.</p>",
      vendor: "Apple",
      product_type: "Cult Products",
      handle: "ipod-nano",
      tags: "MP3, Music",
      status: "active",
      collection_id: 1001, // ✅ This is the key fix!
      image: {
        src: "https://cdn.shopify.com/s/files/1/0005/4838/0009/products/ipod-nano.png"
      },
      created_at: new Date(),
      updated_at: new Date(),
      variants: [
        {
          id: 808950810,
          title: "Pink",
          price: "199.00",
          sku: "IPOD2008PINK",
          taxable: true,
          grams: 567,
          weight: 1.25,
          weight_unit: "lb",
          image: {
            src: "https://cdn.shopify.com/s/files/1/0005/4838/0009/products/ipod-nano.png"
          },
          created_at: new Date(),
          updated_at: new Date()
        }
      ]
    }
  ]);

  console.log("✅ Sample data inserted!");
  process.exit();
}).catch((err) => {
  console.error("❌ Seeding error:", err);
  process.exit(1);
});

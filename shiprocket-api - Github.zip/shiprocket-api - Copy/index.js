const express = require('express');
const connectDB = require('./db');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

connectDB(); // <-- Make sure this is here before anything else

app.use(express.json());

// Mount your routes here
const shiprocketRoutes = require('./routes/shiprocket');
app.use('/', shiprocketRoutes);

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
